package com.KIO4_Base64;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import com.google.appinventor.components.runtime.ActivityResultListener;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Canvas;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.ReplForm;
import com.google.appinventor.components.runtime.errors.YailRuntimeError;
import com.google.appinventor.components.runtime.util.AsynchUtil;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;

public class KIO4_Base64 extends AndroidNonvisibleComponent implements ActivityResultListener, Component {
    public static final int VERSION = 2;
    private final int a;

    /* renamed from: a  reason: collision with other field name */
    private final Activity f8a;
    public ComponentContainer container;
    public Context context;
    public File dir_files;
    public String fileName2;
    public boolean instalado = true;

    public KIO4_Base64(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.container = componentContainer;
        this.context = componentContainer.$context();
        this.f8a = componentContainer.$context();
        this.a = this.form.registerForActivityResult(this);
        if (this.form instanceof ReplForm) {
            this.instalado = false;
        }
    }

    private static void a(InputStream inputStream, OutputStream outputStream) {
        byte[] bArr = new byte[1024];
        while (true) {
            int read = inputStream.read(bArr);
            if (read != -1) {
                outputStream.write(bArr, 0, read);
            } else {
                return;
            }
        }
    }

    public void AfterCanvasBase64(String str) {
        EventDispatcher.dispatchEvent(this, "AfterCanvasBase64", str);
    }

    public void AfterImageBase64(String str) {
        EventDispatcher.dispatchEvent(this, "AfterImageBase64", str);
    }

    public void AfterPictureBase64(String str) {
        EventDispatcher.dispatchEvent(this, "AfterPictureBase64", str);
    }

    public void Base64ToImage(String str, Image image) {
        byte[] decode = Base64.decode(str, 0);
        ((ImageView) image.getView()).setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
    }

    public String Base64ToString(String str) {
        return new String(Base64.decode(str, 0));
    }

    public void CanvasToBase64(Canvas canvas) {
        View view = canvas.getView();
        Method declaredMethod = view.getClass().getDeclaredMethod("buildCache", new Class[0]);
        declaredMethod.setAccessible(true);
        AfterCanvasBase64(bitMapToBase64((Bitmap) declaredMethod.invoke(view, new Object[0])));
    }

    /* JADX WARNING: Removed duplicated region for block: B:26:0x0044 A[SYNTHETIC, Splitter:B:26:0x0044] */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x004b A[SYNTHETIC, Splitter:B:30:0x004b] */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0055 A[SYNTHETIC, Splitter:B:37:0x0055] */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x005c A[SYNTHETIC, Splitter:B:41:0x005c] */
    /* JADX WARNING: Removed duplicated region for block: B:46:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void CopyToASD(java.lang.String r5, java.lang.String r6) {
        /*
            r4 = this;
            r0 = 0
            java.io.FileInputStream r1 = new java.io.FileInputStream     // Catch:{ IOException -> 0x0051, all -> 0x0040 }
            r1.<init>(r5)     // Catch:{ IOException -> 0x0051, all -> 0x0040 }
            java.io.FileOutputStream r5 = new java.io.FileOutputStream     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            r2.<init>()     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            java.lang.String r3 = r4.GetAsdPath()     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            java.lang.String r3 = "/"
            java.lang.StringBuilder r2 = r2.append(r3)     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            java.lang.StringBuilder r6 = r2.append(r6)     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            java.lang.String r6 = r6.toString()     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            r5.<init>(r6)     // Catch:{ IOException -> 0x003c, all -> 0x0038 }
            a(r1, r5)     // Catch:{ IOException -> 0x0036, all -> 0x0034 }
            r1.close()     // Catch:{ IOException -> 0x002d }
            goto L_0x002e
        L_0x002d:
            r6 = move-exception
        L_0x002e:
            r5.close()     // Catch:{ IOException -> 0x0032 }
            return
        L_0x0032:
            r5 = move-exception
            return
        L_0x0034:
            r6 = move-exception
            goto L_0x003a
        L_0x0036:
            r6 = move-exception
            goto L_0x003e
        L_0x0038:
            r6 = move-exception
            r5 = r0
        L_0x003a:
            r0 = r1
            goto L_0x0042
        L_0x003c:
            r5 = move-exception
            r5 = r0
        L_0x003e:
            r0 = r1
            goto L_0x0053
        L_0x0040:
            r6 = move-exception
            r5 = r0
        L_0x0042:
            if (r0 == 0) goto L_0x0049
            r0.close()     // Catch:{ IOException -> 0x0048 }
            goto L_0x0049
        L_0x0048:
            r0 = move-exception
        L_0x0049:
            if (r5 == 0) goto L_0x0050
            r5.close()     // Catch:{ IOException -> 0x004f }
            goto L_0x0050
        L_0x004f:
            r5 = move-exception
        L_0x0050:
            throw r6
        L_0x0051:
            r5 = move-exception
            r5 = r0
        L_0x0053:
            if (r0 == 0) goto L_0x005a
            r0.close()     // Catch:{ IOException -> 0x0059 }
            goto L_0x005a
        L_0x0059:
            r6 = move-exception
        L_0x005a:
            if (r5 == 0) goto L_0x0061
            r5.close()     // Catch:{ IOException -> 0x0060 }
            return
        L_0x0060:
            r5 = move-exception
        L_0x0061:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.KIO4_Base64.KIO4_Base64.CopyToASD(java.lang.String, java.lang.String):void");
    }

    public void CreateDirectory(String str) {
        File file = new File(Environment.getExternalStorageDirectory() + str);
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    public void CreateDirectoryASD(String str) {
        File file = new File(GetAsdPath() + str);
        if (!file.exists()) {
            file.mkdirs();
        }
    }

    public void DeleteDirectory(String str) {
        File file = new File("/mnt/sdcard".concat(String.valueOf(str)));
        if (file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                new File(file, file2).delete();
            }
            file.delete();
        }
    }

    public void DeleteDirectoryASD(String str) {
        File file = new File(GetAsdPath() + str);
        if (file.isDirectory()) {
            String[] list = file.list();
            for (String file2 : list) {
                new File(file, file2).delete();
            }
            file.delete();
        }
    }

    public void DeleteFile(String str) {
        try {
            Files.delete(Paths.get(str, new String[0]));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void DownloadFile(String str, String str2) {
        Uri parse = Uri.parse(str);
        String substring = str.substring(str.lastIndexOf(47) + 1);
        DownloadManager.Request request = new DownloadManager.Request(parse);
        request.setTitle("My File");
        request.setDescription("Downloading");
        request.setNotificationVisibility(1);
        request.setVisibleInDownloadsUi(true);
        request.setDestinationUri(Uri.parse("file://" + Environment.getExternalStorageDirectory() + str2 + "/" + substring));
        ((DownloadManager) this.context.getSystemService("download")).enqueue(request);
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void DownloadFileASD(String str, String str2) {
        Uri parse = Uri.parse(str);
        String substring = str.substring(str.lastIndexOf(47) + 1);
        DownloadManager.Request request = new DownloadManager.Request(parse);
        request.setTitle("My File");
        request.setDescription("Downloading");
        request.setNotificationVisibility(1);
        request.setVisibleInDownloadsUi(true);
        request.setDestinationUri(Uri.parse("file://" + GetAsdPath() + str2 + "/" + substring));
        ((DownloadManager) this.context.getSystemService("download")).enqueue(request);
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void DownloadFileToASD(String str, String str2) {
        Uri parse = Uri.parse(str);
        str.substring(str.lastIndexOf(47) + 1);
        DownloadManager.Request request = new DownloadManager.Request(parse);
        request.setTitle("My File");
        request.setDescription("Downloading");
        request.setNotificationVisibility(1);
        request.setVisibleInDownloadsUi(true);
        request.setDestinationUri(Uri.parse("file://" + GetAsdPath() + str2));
        ((DownloadManager) this.context.getSystemService("download")).enqueue(request);
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public boolean FileExists(String str) {
        return new File(str).exists();
    }

    public void FileToString(String str) {
        String str2;
        if (str.startsWith("//")) {
            if (!this.instalado) {
                try {
                    str2 = Environment.getExternalStorageDirectory().getPath() + "/AppInventor/assets" + str.substring(1);
                    File file = new File(str2);
                    FileInputStream fileInputStream = new FileInputStream(file);
                    byte[] bArr = new byte[((int) file.length())];
                    fileInputStream.read(bArr);
                    GotString(Base64.encodeToString(bArr, 0));
                    fileInputStream.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else {
                String substring = str.substring(2);
                File file2 = new File(this.context.getCacheDir() + substring);
                if (!file2.exists()) {
                    try {
                        InputStream open = this.context.getAssets().open(substring);
                        byte[] bArr2 = new byte[open.available()];
                        open.read(bArr2);
                        open.close();
                        FileOutputStream fileOutputStream = new FileOutputStream(file2);
                        fileOutputStream.write(bArr2);
                        fileOutputStream.close();
                    } catch (Exception e2) {
                        throw new RuntimeException(e2);
                    }
                }
                str2 = file2.getPath();
            }
            File file3 = new File(str2);
            file3.length();
            try {
                FileInputStream fileInputStream2 = new FileInputStream(file3);
                byte[] bArr3 = new byte[((int) file3.length())];
                fileInputStream2.read(bArr3);
                GotString(Base64.encodeToString(bArr3, 0));
                fileInputStream2.close();
            } catch (FileNotFoundException e3) {
                GotString("File not found.");
            } catch (IOException e4) {
                GotString("Error en la lectura del archivo.");
            }
        } else {
            if (str.startsWith("/")) {
                File file4 = new File(str);
                try {
                    FileInputStream fileInputStream3 = new FileInputStream(file4);
                    byte[] bArr4 = new byte[((int) file4.length())];
                    fileInputStream3.read(bArr4);
                    GotString(Base64.encodeToString(bArr4, 0));
                    fileInputStream3.close();
                    return;
                } catch (FileNotFoundException e5) {
                } catch (IOException e6) {
                    GotString("Error en la lectura del archivo.");
                    return;
                }
            }
            GotString("File not found.");
        }
    }

    public void FileToStringASD(String str) {
        String str2;
        if (str.startsWith("//")) {
            if (!this.instalado) {
                try {
                    str2 = Environment.getExternalStorageDirectory().getPath() + "/AppInventor/assets" + str.substring(1);
                    File file = new File(str2);
                    FileInputStream fileInputStream = new FileInputStream(file);
                    byte[] bArr = new byte[((int) file.length())];
                    fileInputStream.read(bArr);
                    GotString(Base64.encodeToString(bArr, 0));
                    fileInputStream.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else {
                String substring = str.substring(2);
                File file2 = new File(this.context.getCacheDir() + substring);
                if (!file2.exists()) {
                    try {
                        InputStream open = this.context.getAssets().open(substring);
                        byte[] bArr2 = new byte[open.available()];
                        open.read(bArr2);
                        open.close();
                        FileOutputStream fileOutputStream = new FileOutputStream(file2);
                        fileOutputStream.write(bArr2);
                        fileOutputStream.close();
                    } catch (Exception e2) {
                        throw new RuntimeException(e2);
                    }
                }
                str2 = file2.getPath();
            }
            File file3 = new File(str2);
            file3.length();
            try {
                FileInputStream fileInputStream2 = new FileInputStream(file3);
                byte[] bArr3 = new byte[((int) file3.length())];
                fileInputStream2.read(bArr3);
                GotString(Base64.encodeToString(bArr3, 0));
                fileInputStream2.close();
            } catch (FileNotFoundException e3) {
                GotString("File not found.");
            } catch (IOException e4) {
                GotString("Error en la lectura del archivo.");
            }
        } else {
            if (str.startsWith("/")) {
                File file4 = new File(GetAsdPath() + str);
                try {
                    FileInputStream fileInputStream3 = new FileInputStream(file4);
                    byte[] bArr4 = new byte[((int) file4.length())];
                    fileInputStream3.read(bArr4);
                    GotString(Base64.encodeToString(bArr4, 0));
                    fileInputStream3.close();
                    return;
                } catch (FileNotFoundException e5) {
                } catch (IOException e6) {
                    GotString("Error en la lectura del archivo.");
                    return;
                }
            }
            GotString("File not found.");
        }
    }

    public String FileToStringDirect(String str) {
        File file = new File(str);
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bArr = new byte[((int) file.length())];
            fileInputStream.read(bArr);
            String encodeToString = Base64.encodeToString(bArr, 0);
            fileInputStream.close();
            return encodeToString;
        } catch (FileNotFoundException e) {
            return "File not found.";
        } catch (IOException e2) {
            return "Error en la lectura del archivo.";
        }
    }

    public int GetApi() {
        int i = -1;
        for (Field field : Build.VERSION_CODES.class.getFields()) {
            field.getName();
            try {
                i = field.getInt(new Object());
            } catch (IllegalAccessException | IllegalArgumentException | NullPointerException e) {
                i = -1;
            }
        }
        return i;
    }

    public String GetAsdPath() {
        PackageManager packageManager = this.context.getPackageManager();
        String packageName = this.context.getPackageName();
        try {
            packageManager.getPackageInfo(packageName, 0);
        } catch (Exception e) {
            packageName = "Not_found.";
        }
        this.dir_files = new File("/storage/emulated/0/Android/data/" + packageName + "/files");
        if (!this.context.getExternalFilesDir((String) null).exists()) {
            this.context.getExternalFilesDir((String) null).mkdirs();
        }
        return "/storage/emulated/0/Android/data/" + packageName + "/files";
    }

    public String GetMimeType(String str) {
        String guessContentTypeFromName = URLConnection.guessContentTypeFromName(new File(str).getName());
        return guessContentTypeFromName.contains("comma-separated-values") ? "text/csv" : guessContentTypeFromName;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0030 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String GetSdkCodeName() {
        /*
            r7 = this;
            java.lang.Class<android.os.Build$VERSION_CODES> r0 = android.os.Build.VERSION_CODES.class
            java.lang.reflect.Field[] r0 = r0.getFields()
            int r1 = r0.length
            java.lang.String r2 = ""
            r3 = 0
        L_0x000a:
            if (r3 >= r1) goto L_0x0033
            r4 = r0[r3]
            java.lang.String r5 = r4.getName()
            java.lang.Object r6 = new java.lang.Object     // Catch:{ IllegalArgumentException -> 0x0026, IllegalAccessException -> 0x0021, NullPointerException -> 0x001c }
            r6.<init>()     // Catch:{ IllegalArgumentException -> 0x0026, IllegalAccessException -> 0x0021, NullPointerException -> 0x001c }
            int r4 = r4.getInt(r6)     // Catch:{ IllegalArgumentException -> 0x0026, IllegalAccessException -> 0x0021, NullPointerException -> 0x001c }
            goto L_0x002b
        L_0x001c:
            r4 = move-exception
            r4.printStackTrace()
            goto L_0x002a
        L_0x0021:
            r4 = move-exception
            r4.printStackTrace()
            goto L_0x002a
        L_0x0026:
            r4 = move-exception
            r4.printStackTrace()
        L_0x002a:
            r4 = -1
        L_0x002b:
            int r6 = android.os.Build.VERSION.SDK_INT
            if (r4 != r6) goto L_0x0030
            r2 = r5
        L_0x0030:
            int r3 = r3 + 1
            goto L_0x000a
        L_0x0033:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.KIO4_Base64.KIO4_Base64.GetSdkCodeName():java.lang.String");
    }

    public void GotFile(String str) {
        EventDispatcher.dispatchEvent(this, "GotFile", str);
    }

    public void GotString(String str) {
        EventDispatcher.dispatchEvent(this, "GotString", str);
    }

    public void GotStringFromWebFile(String str) {
        EventDispatcher.dispatchEvent(this, "GotStringFromWebFile", str);
    }

    public void ImageToBase64(Image image) {
        AfterImageBase64(bitMapToBase64(((BitmapDrawable) ((ImageView) image.getView()).getDrawable()).getBitmap()));
    }

    public String StringToBase64(String str) {
        return Base64.encodeToString(str.getBytes(), 0);
    }

    public void StringToFile(String str, String str2) {
        String str3;
        new File(str2);
        try {
            byte[] decode = Base64.decode(str, 0);
            FileOutputStream fileOutputStream = new FileOutputStream("/mnt/sdcard".concat(String.valueOf(str2)));
            fileOutputStream.write(decode);
            fileOutputStream.close();
            GotFile(str2);
        } catch (FileNotFoundException e) {
            str3 = "File not found.";
            GotString(str3);
        } catch (IOException e2) {
            str3 = "Error en la lectura del archivo.";
            GotString(str3);
        }
    }

    public void StringToFileASD(String str, String str2) {
        String str3;
        new File(str2);
        try {
            byte[] decode = Base64.decode(str, 0);
            FileOutputStream fileOutputStream = new FileOutputStream(GetAsdPath() + str2);
            fileOutputStream.write(decode);
            fileOutputStream.close();
            GotFile(str2);
        } catch (FileNotFoundException e) {
            str3 = "File not found.";
            GotFile(str3);
        } catch (IOException e2) {
            str3 = "Error en la lectura del archivo.";
            GotFile(str3);
        }
    }

    public void StringToFileASDAsyn(String str, String str2) {
        new File(str2);
        this.fileName2 = str2;
        AsynchUtil.runAsynchronously(new a(this, str, str2));
    }

    public String StringToFileASDDirect(String str, String str2) {
        new File(str2);
        try {
            byte[] decode = Base64.decode(str, 0);
            FileOutputStream fileOutputStream = new FileOutputStream(GetAsdPath() + str2);
            fileOutputStream.write(decode);
            fileOutputStream.close();
            return str2;
        } catch (FileNotFoundException e) {
            return "File not found.";
        } catch (IOException e2) {
            return "Error en la lectura del archivo.";
        }
    }

    public void TakePictureToBase64() {
        try {
            this.f8a.startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), this.a);
        } catch (ActivityNotFoundException e) {
            throw new YailRuntimeError(e.getMessage(), "Cannot start activity");
        }
    }

    public String UriToPath(String str) {
        try {
            new FileUtils();
            return FileUtils.getPath(this.context, Uri.parse(str));
        } catch (Exception e) {
            return null;
        }
    }

    public void WebFileToString(String str) {
        File file = new File(Environment.getExternalStorageDirectory() + File.separator + "auxiliar2");
        if (!file.exists()) {
            file.mkdirs();
        }
        Uri parse = Uri.parse(str);
        String substring = str.substring(str.lastIndexOf(47) + 1);
        DownloadManager.Request request = new DownloadManager.Request(parse);
        request.setTitle("My File");
        request.setDescription("Downloading");
        request.setNotificationVisibility(1);
        request.setVisibleInDownloadsUi(false);
        request.setDestinationUri(Uri.parse("file:///mnt/sdcard/auxiliar2/".concat(String.valueOf(substring))));
        ((DownloadManager) this.context.getSystemService("download")).enqueue(request);
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        File file2 = new File("/mnt/sdcard/auxiliar2/".concat(String.valueOf(substring)));
        try {
            FileInputStream fileInputStream = new FileInputStream(file2);
            byte[] bArr = new byte[((int) file2.length())];
            fileInputStream.read(bArr);
            GotString(Base64.encodeToString(bArr, 0));
            fileInputStream.close();
        } catch (FileNotFoundException e2) {
        } catch (IOException e3) {
            GotString("Error en la lectura del archivo.");
        }
        try {
            Thread.sleep(200);
        } catch (Exception e4) {
            e4.printStackTrace();
        }
        File file3 = new File("/mnt/sdcard/auxiliar2");
        if (file3.isDirectory()) {
            String[] list = file3.list();
            for (String file4 : list) {
                new File(file3, file4).delete();
            }
            file3.delete();
        }
    }

    public void WebFileToStringASD(String str) {
        File file = new File(GetAsdPath() + "/temp");
        if (!file.exists()) {
            file.mkdirs();
        }
        Uri parse = Uri.parse(str);
        String substring = str.substring(str.lastIndexOf(47) + 1);
        DownloadManager.Request request = new DownloadManager.Request(parse);
        request.setTitle("My File");
        request.setDescription("Downloading");
        request.setNotificationVisibility(1);
        request.setVisibleInDownloadsUi(false);
        request.setDestinationUri(Uri.parse("file://" + GetAsdPath() + "/temp/" + substring));
        ((DownloadManager) this.context.getSystemService("download")).enqueue(request);
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        File file2 = new File(GetAsdPath() + "/temp/" + substring);
        try {
            FileInputStream fileInputStream = new FileInputStream(file2);
            byte[] bArr = new byte[((int) file2.length())];
            fileInputStream.read(bArr);
            GotStringFromWebFile(Base64.encodeToString(bArr, 0));
            fileInputStream.close();
        } catch (FileNotFoundException e2) {
        } catch (IOException e3) {
            GotStringFromWebFile("Error en la lectura del archivo.");
        }
    }

    public String bitMapToBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 50, byteArrayOutputStream);
        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0);
    }

    public void resultReturned(int i, int i2, Intent intent) {
        if (i == this.a && i2 == -1) {
            AfterPictureBase64(bitMapToBase64((Bitmap) intent.getExtras().get("data")));
        }
    }
}
