package com.KIO4_Base64;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class FileUtils {
    private static Uri a = null;

    /* JADX WARNING: Removed duplicated region for block: B:18:0x0037  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.String a(android.content.Context r8, android.net.Uri r9, java.lang.String r10, java.lang.String[] r11) {
        /*
            r0 = 1
            java.lang.String[] r3 = new java.lang.String[r0]
            r0 = 0
            java.lang.String r7 = "_data"
            r3[r0] = r7
            r0 = 0
            android.content.ContentResolver r1 = r8.getContentResolver()     // Catch:{ all -> 0x0034 }
            r6 = 0
            r2 = r9
            r4 = r10
            r5 = r11
            android.database.Cursor r8 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ all -> 0x0034 }
            if (r8 == 0) goto L_0x002e
            boolean r9 = r8.moveToFirst()     // Catch:{ all -> 0x002b }
            if (r9 == 0) goto L_0x002e
            int r9 = r8.getColumnIndexOrThrow(r7)     // Catch:{ all -> 0x002b }
            java.lang.String r9 = r8.getString(r9)     // Catch:{ all -> 0x002b }
            if (r8 == 0) goto L_0x002a
            r8.close()
        L_0x002a:
            return r9
        L_0x002b:
            r9 = move-exception
            r0 = r8
            goto L_0x0035
        L_0x002e:
            if (r8 == 0) goto L_0x0033
            r8.close()
        L_0x0033:
            return r0
        L_0x0034:
            r9 = move-exception
        L_0x0035:
            if (r0 == 0) goto L_0x003a
            r0.close()
        L_0x003a:
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.KIO4_Base64.FileUtils.a(android.content.Context, android.net.Uri, java.lang.String, java.lang.String[]):java.lang.String");
    }

    private static String a(Uri uri, Context context) {
        Cursor query = context.getContentResolver().query(uri, (String[]) null, (String) null, (String[]) null, (String) null);
        int columnIndex = query.getColumnIndex("_display_name");
        int columnIndex2 = query.getColumnIndex("_size");
        query.moveToFirst();
        String string = query.getString(columnIndex);
        Long.toString(query.getLong(columnIndex2));
        File file = new File(context.getCacheDir(), string);
        try {
            InputStream openInputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[Math.min(openInputStream.available(), 1048576)];
            while (true) {
                int read = openInputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            Log.e("File Size", "Size " + file.length());
            openInputStream.close();
            fileOutputStream.close();
            Log.e("File Path", "Path " + file.getPath());
            Log.e("File Size", "Size " + file.length());
        } catch (Exception e) {
            Log.e("Exception", e.getMessage());
        }
        return file.getPath();
    }

    private static boolean a(Uri uri) {
        return "com.google.android.apps.docs.storage".equals(uri.getAuthority()) || "com.google.android.apps.docs.storage.legacy".equals(uri.getAuthority());
    }

    private static boolean a(String str) {
        return new File(str).exists();
    }

    private static String b(Uri uri, Context context) {
        Cursor query = context.getContentResolver().query(uri, (String[]) null, (String) null, (String[]) null, (String) null);
        int columnIndex = query.getColumnIndex("_display_name");
        int columnIndex2 = query.getColumnIndex("_size");
        query.moveToFirst();
        String string = query.getString(columnIndex);
        Long.toString(query.getLong(columnIndex2));
        File file = new File(context.getFilesDir(), string);
        try {
            InputStream openInputStream = context.getContentResolver().openInputStream(uri);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[Math.min(openInputStream.available(), 1048576)];
            while (true) {
                int read = openInputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            Log.e("File Size", "Size " + file.length());
            openInputStream.close();
            fileOutputStream.close();
            Log.e("File Path", "Path " + file.getPath());
            Log.e("File Size", "Size " + file.length());
        } catch (Exception e) {
            Log.e("Exception", e.getMessage());
        }
        return file.getPath();
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v2, resolved type: android.net.Uri} */
    /* JADX WARNING: type inference failed for: r1v1 */
    /* JADX WARNING: type inference failed for: r1v6, types: [android.database.Cursor] */
    /* JADX WARNING: type inference failed for: r1v7 */
    /* JADX WARNING: type inference failed for: r1v8 */
    /* JADX WARNING: type inference failed for: r1v9 */
    /* JADX WARNING: type inference failed for: r1v10 */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0060, code lost:
        if (a(r15) == false) goto L_0x0062;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x014c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String getPath(android.content.Context r14, android.net.Uri r15) {
        /*
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 19
            r2 = 1
            r3 = 0
            if (r0 < r1) goto L_0x000a
            r0 = 1
            goto L_0x000b
        L_0x000a:
            r0 = 0
        L_0x000b:
            r1 = 0
            if (r0 == 0) goto L_0x01cd
            boolean r0 = android.provider.DocumentsContract.isDocumentUri(r14, r15)
            if (r0 == 0) goto L_0x01cd
            java.lang.String r0 = "com.android.externalstorage.documents"
            java.lang.String r4 = r15.getAuthority()
            boolean r0 = r0.equals(r4)
            java.lang.String r4 = ":"
            java.lang.String r5 = ""
            if (r0 == 0) goto L_0x009d
            java.lang.String r14 = android.provider.DocumentsContract.getDocumentId(r15)
            java.lang.String[] r14 = r14.split(r4)
            r15 = r14[r3]
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r3 = "/"
            r0.<init>(r3)
            r14 = r14[r2]
            java.lang.StringBuilder r14 = r0.append(r14)
            java.lang.String r14 = r14.toString()
            java.lang.String r0 = "primary"
            boolean r15 = r0.equalsIgnoreCase(r15)
            if (r15 == 0) goto L_0x0062
            java.lang.StringBuilder r15 = new java.lang.StringBuilder
            r15.<init>()
            java.io.File r0 = android.os.Environment.getExternalStorageDirectory()
            java.lang.StringBuilder r15 = r15.append(r0)
            java.lang.StringBuilder r15 = r15.append(r14)
            java.lang.String r15 = r15.toString()
            boolean r0 = a((java.lang.String) r15)
            if (r0 != 0) goto L_0x0099
        L_0x0062:
            java.lang.StringBuilder r15 = new java.lang.StringBuilder
            r15.<init>()
            java.lang.String r0 = "SECONDARY_STORAGE"
            java.lang.String r0 = java.lang.System.getenv(r0)
            java.lang.StringBuilder r15 = r15.append(r0)
            java.lang.StringBuilder r15 = r15.append(r14)
            java.lang.String r15 = r15.toString()
            boolean r0 = a((java.lang.String) r15)
            if (r0 != 0) goto L_0x0099
            java.lang.StringBuilder r15 = new java.lang.StringBuilder
            r15.<init>()
            java.lang.String r0 = "EXTERNAL_STORAGE"
            java.lang.String r0 = java.lang.System.getenv(r0)
            java.lang.StringBuilder r15 = r15.append(r0)
            java.lang.StringBuilder r14 = r15.append(r14)
            java.lang.String r15 = r14.toString()
            a((java.lang.String) r15)
        L_0x0099:
            if (r15 == r5) goto L_0x009c
            return r15
        L_0x009c:
            return r1
        L_0x009d:
            java.lang.String r0 = "com.android.providers.downloads.documents"
            java.lang.String r6 = r15.getAuthority()
            boolean r0 = r0.equals(r6)
            if (r0 == 0) goto L_0x017f
            int r0 = android.os.Build.VERSION.SDK_INT
            r4 = 23
            java.lang.String r6 = "content://downloads/public_downloads"
            java.lang.String r7 = "raw:"
            if (r0 < r4) goto L_0x0150
            android.content.ContentResolver r8 = r14.getContentResolver()     // Catch:{ all -> 0x0149 }
            java.lang.String[] r10 = new java.lang.String[r2]     // Catch:{ all -> 0x0149 }
            java.lang.String r0 = "_display_name"
            r10[r3] = r0     // Catch:{ all -> 0x0149 }
            r11 = 0
            r12 = 0
            r13 = 0
            r9 = r15
            android.database.Cursor r0 = r8.query(r9, r10, r11, r12, r13)     // Catch:{ all -> 0x0149 }
            if (r0 == 0) goto L_0x00ff
            boolean r4 = r0.moveToFirst()     // Catch:{ all -> 0x00fc }
            if (r4 == 0) goto L_0x00ff
            java.lang.String r4 = r0.getString(r3)     // Catch:{ all -> 0x00fc }
            java.lang.StringBuilder r8 = new java.lang.StringBuilder     // Catch:{ all -> 0x00fc }
            r8.<init>()     // Catch:{ all -> 0x00fc }
            java.io.File r9 = android.os.Environment.getExternalStorageDirectory()     // Catch:{ all -> 0x00fc }
            java.lang.String r9 = r9.toString()     // Catch:{ all -> 0x00fc }
            java.lang.StringBuilder r8 = r8.append(r9)     // Catch:{ all -> 0x00fc }
            java.lang.String r9 = "/Download/"
            java.lang.StringBuilder r8 = r8.append(r9)     // Catch:{ all -> 0x00fc }
            java.lang.StringBuilder r4 = r8.append(r4)     // Catch:{ all -> 0x00fc }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x00fc }
            boolean r8 = android.text.TextUtils.isEmpty(r4)     // Catch:{ all -> 0x00fc }
            if (r8 != 0) goto L_0x00ff
            if (r0 == 0) goto L_0x00fb
            r0.close()
        L_0x00fb:
            return r4
        L_0x00fc:
            r14 = move-exception
            r1 = r0
            goto L_0x014a
        L_0x00ff:
            if (r0 == 0) goto L_0x0104
            r0.close()
        L_0x0104:
            java.lang.String r0 = android.provider.DocumentsContract.getDocumentId(r15)
            boolean r4 = android.text.TextUtils.isEmpty(r0)
            if (r4 != 0) goto L_0x0216
            boolean r4 = r0.startsWith(r7)
            if (r4 == 0) goto L_0x0119
            java.lang.String r14 = r0.replaceFirst(r7, r5)
            return r14
        L_0x0119:
            r4 = 2
            java.lang.String[] r4 = new java.lang.String[r4]
            r4[r3] = r6
            java.lang.String r3 = "content://downloads/my_downloads"
            r4[r2] = r3
            android.net.Uri r2 = android.net.Uri.parse(r6)     // Catch:{ NumberFormatException -> 0x0137 }
            java.lang.Long r0 = java.lang.Long.valueOf(r0)     // Catch:{ NumberFormatException -> 0x0137 }
            long r3 = r0.longValue()     // Catch:{ NumberFormatException -> 0x0137 }
            android.net.Uri r0 = android.content.ContentUris.withAppendedId(r2, r3)     // Catch:{ NumberFormatException -> 0x0137 }
            java.lang.String r14 = a(r14, r0, r1, r1)     // Catch:{ NumberFormatException -> 0x0137 }
            return r14
        L_0x0137:
            r14 = move-exception
            java.lang.String r14 = r15.getPath()
            java.lang.String r15 = "^/document/raw:"
            java.lang.String r14 = r14.replaceFirst(r15, r5)
            java.lang.String r15 = "^raw:"
            java.lang.String r14 = r14.replaceFirst(r15, r5)
            return r14
        L_0x0149:
            r14 = move-exception
        L_0x014a:
            if (r1 == 0) goto L_0x014f
            r1.close()
        L_0x014f:
            throw r14
        L_0x0150:
            java.lang.String r15 = android.provider.DocumentsContract.getDocumentId(r15)
            boolean r0 = r15.startsWith(r7)
            if (r0 == 0) goto L_0x015f
            java.lang.String r14 = r15.replaceFirst(r7, r5)
            return r14
        L_0x015f:
            android.net.Uri r0 = android.net.Uri.parse(r6)     // Catch:{ NumberFormatException -> 0x0172 }
            java.lang.Long r15 = java.lang.Long.valueOf(r15)     // Catch:{ NumberFormatException -> 0x0172 }
            long r2 = r15.longValue()     // Catch:{ NumberFormatException -> 0x0172 }
            android.net.Uri r15 = android.content.ContentUris.withAppendedId(r0, r2)     // Catch:{ NumberFormatException -> 0x0172 }
            a = r15     // Catch:{ NumberFormatException -> 0x0172 }
            goto L_0x0176
        L_0x0172:
            r15 = move-exception
            r15.printStackTrace()
        L_0x0176:
            android.net.Uri r15 = a
            if (r15 == 0) goto L_0x0216
            java.lang.String r14 = a(r14, r15, r1, r1)
            return r14
        L_0x017f:
            java.lang.String r0 = "com.android.providers.media.documents"
            java.lang.String r5 = r15.getAuthority()
            boolean r0 = r0.equals(r5)
            if (r0 == 0) goto L_0x01c2
            java.lang.String r15 = android.provider.DocumentsContract.getDocumentId(r15)
            java.lang.String[] r15 = r15.split(r4)
            r0 = r15[r3]
            java.lang.String r4 = "image"
            boolean r4 = r4.equals(r0)
            if (r4 == 0) goto L_0x01a0
            android.net.Uri r1 = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            goto L_0x01b5
        L_0x01a0:
            java.lang.String r4 = "video"
            boolean r4 = r4.equals(r0)
            if (r4 == 0) goto L_0x01ab
            android.net.Uri r1 = android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            goto L_0x01b5
        L_0x01ab:
            java.lang.String r4 = "audio"
            boolean r0 = r4.equals(r0)
            if (r0 == 0) goto L_0x01b5
            android.net.Uri r1 = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        L_0x01b5:
            java.lang.String[] r0 = new java.lang.String[r2]
            r15 = r15[r2]
            r0[r3] = r15
            java.lang.String r15 = "_id=?"
            java.lang.String r14 = a(r14, r1, r15, r0)
            return r14
        L_0x01c2:
            boolean r0 = a((android.net.Uri) r15)
            if (r0 == 0) goto L_0x0216
            java.lang.String r14 = a(r15, r14)
            return r14
        L_0x01cd:
            java.lang.String r0 = "content"
            java.lang.String r2 = r15.getScheme()
            boolean r0 = r0.equalsIgnoreCase(r2)
            if (r0 == 0) goto L_0x0205
            java.lang.String r0 = "com.google.android.apps.photos.content"
            java.lang.String r2 = r15.getAuthority()
            boolean r0 = r0.equals(r2)
            if (r0 == 0) goto L_0x01ea
            java.lang.String r14 = r15.getLastPathSegment()
            return r14
        L_0x01ea:
            boolean r0 = a((android.net.Uri) r15)
            if (r0 == 0) goto L_0x01f5
            java.lang.String r14 = a(r15, r14)
            return r14
        L_0x01f5:
            int r0 = android.os.Build.VERSION.SDK_INT
            r2 = 24
            if (r0 != r2) goto L_0x0200
            java.lang.String r14 = b(r15, r14)
            return r14
        L_0x0200:
            java.lang.String r14 = a(r14, r15, r1, r1)
            return r14
        L_0x0205:
            java.lang.String r14 = "file"
            java.lang.String r0 = r15.getScheme()
            boolean r14 = r14.equalsIgnoreCase(r0)
            if (r14 == 0) goto L_0x0216
            java.lang.String r14 = r15.getPath()
            return r14
        L_0x0216:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.KIO4_Base64.FileUtils.getPath(android.content.Context, android.net.Uri):java.lang.String");
    }
}
