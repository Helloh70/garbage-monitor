package com.google.appinventor.components.annotations;

/* renamed from: com.google.appinventor.components.annotations.package-info  reason: invalid class name */
interface packageinfo {
}
