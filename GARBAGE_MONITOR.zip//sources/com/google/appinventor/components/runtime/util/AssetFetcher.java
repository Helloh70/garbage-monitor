package com.google.appinventor.components.runtime.util;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.ReplForm;
import java.io.File;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;

public class AssetFetcher {
    /* access modifiers changed from: private */
    public static final String LOG_TAG = AssetFetcher.class.getSimpleName();
    private static ExecutorService background = Executors.newSingleThreadExecutor();
    private static Context context = ReplForm.getActiveForm();
    private static HashDatabase db = new HashDatabase(context);
    private static volatile boolean inError = false;
    private static final Object semaphore = new Object();

    private AssetFetcher() {
    }

    public static void fetchAssets(final String cookieValue, final String projectId, final String uri, final String asset) {
        background.submit(new Runnable() {
            public void run() {
                String str = uri;
                String str2 = projectId;
                if (AssetFetcher.getFile(str + "/ode/download/file/" + str2 + "/" + asset, cookieValue, asset, 0) != null) {
                    RetValManager.assetTransferred(asset);
                }
            }
        });
    }

    public static void upgradeCompanion(final String cookieValue, final String inputUri) {
        background.submit(new Runnable() {
            public void run() {
                String[] parts = inputUri.split("/", 0);
                File assetFile = AssetFetcher.getFile(inputUri, cookieValue, parts[parts.length - 1], 0);
                if (assetFile != null) {
                    try {
                        Form form = Form.getActiveForm();
                        Intent intent = new Intent("android.intent.action.VIEW");
                        intent.setDataAndType(NougatUtil.getPackageUri(form, assetFile), "application/vnd.android.package-archive");
                        intent.setFlags(1);
                        form.startActivity(intent);
                    } catch (Exception e) {
                        Log.e(AssetFetcher.LOG_TAG, "ERROR_UNABLE_TO_GET", e);
                        RetValManager.sendError("Unable to Install new Companion Package.");
                    }
                }
            }
        });
    }

    public static void loadExtensions(String jsonString) {
        String str = LOG_TAG;
        Log.d(str, "loadExtensions called jsonString = " + jsonString);
        try {
            ReplForm form = (ReplForm) Form.getActiveForm();
            JSONArray array = new JSONArray(jsonString);
            List<String> extensionsToLoad = new ArrayList<>();
            if (array.length() == 0) {
                Log.d(str, "loadExtensions: No Extensions");
                RetValManager.extensionsLoaded();
                return;
            }
            int i = 0;
            while (i < array.length()) {
                String extensionName = array.optString(i);
                if (extensionName != null) {
                    Log.d(LOG_TAG, "loadExtensions, extensionName = " + extensionName);
                    extensionsToLoad.add(extensionName);
                    i++;
                } else {
                    Log.e(LOG_TAG, "extensionName was null");
                    return;
                }
            }
            try {
                form.loadComponents(extensionsToLoad);
                RetValManager.extensionsLoaded();
            } catch (Exception e) {
                Log.e(LOG_TAG, "Error in form.loadComponents", e);
            }
        } catch (JSONException e2) {
            Log.e(LOG_TAG, "JSON Exception parsing extension string", e2);
        }
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x01ec A[Catch:{ Exception -> 0x027f }] */
    /* JADX WARNING: Removed duplicated region for block: B:109:0x0238 A[Catch:{ Exception -> 0x027f }] */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x027b A[Catch:{ Exception -> 0x027f }] */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x028d  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x0292  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x029b  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x008f A[Catch:{ Exception -> 0x02c0 }] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.io.File getFile(java.lang.String r21, java.lang.String r22, java.lang.String r23, int r24) {
        /*
            r1 = r21
            r2 = r22
            r3 = r23
            r4 = r24
            com.google.appinventor.components.runtime.Form r5 = com.google.appinventor.components.runtime.Form.getActiveForm()
            r6 = 0
            r0 = 1
            if (r4 <= r0) goto L_0x0028
            java.lang.Object r7 = semaphore
            monitor-enter(r7)
            boolean r8 = inError     // Catch:{ all -> 0x0025 }
            if (r8 == 0) goto L_0x0019
            monitor-exit(r7)     // Catch:{ all -> 0x0025 }
            return r6
        L_0x0019:
            inError = r0     // Catch:{ all -> 0x0025 }
            com.google.appinventor.components.runtime.util.AssetFetcher$3 r0 = new com.google.appinventor.components.runtime.util.AssetFetcher$3     // Catch:{ all -> 0x0025 }
            r0.<init>(r1)     // Catch:{ all -> 0x0025 }
            r5.runOnUiThread(r0)     // Catch:{ all -> 0x0025 }
            monitor-exit(r7)     // Catch:{ all -> 0x0025 }
            return r6
        L_0x0025:
            r0 = move-exception
            monitor-exit(r7)     // Catch:{ all -> 0x0025 }
            throw r0
        L_0x0028:
            r7 = 0
            java.io.File r8 = new java.io.File
            java.lang.String r9 = com.google.appinventor.components.runtime.util.QUtil.getReplAssetPath(r5, r0)
            java.lang.String r10 = "assets/"
            int r10 = r10.length()
            java.lang.String r10 = r3.substring(r10)
            r8.<init>(r9, r10)
            java.lang.String r9 = LOG_TAG
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String r11 = "target file = "
            java.lang.StringBuilder r10 = r10.append(r11)
            java.lang.StringBuilder r10 = r10.append(r8)
            java.lang.String r10 = r10.toString()
            android.util.Log.d(r9, r10)
            r10 = 0
            r11 = 0
            java.lang.String r12 = "/external_comps/"
            boolean r12 = r3.contains(r12)     // Catch:{ Exception -> 0x02c0 }
            if (r12 == 0) goto L_0x006b
            int r12 = android.os.Build.VERSION.SDK_INT     // Catch:{ Exception -> 0x0066 }
            r13 = 34
            if (r12 < r13) goto L_0x006b
            r12 = 1
            goto L_0x006c
        L_0x0066:
            r0 = move-exception
            r17 = r5
            goto L_0x02c3
        L_0x006b:
            r12 = 0
        L_0x006c:
            java.lang.StringBuilder r13 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02c0 }
            r13.<init>()     // Catch:{ Exception -> 0x02c0 }
            java.lang.String r14 = "makeReadonly = "
            java.lang.StringBuilder r13 = r13.append(r14)     // Catch:{ Exception -> 0x02c0 }
            java.lang.StringBuilder r13 = r13.append(r12)     // Catch:{ Exception -> 0x02c0 }
            java.lang.String r13 = r13.toString()     // Catch:{ Exception -> 0x02c0 }
            android.util.Log.i(r9, r13)     // Catch:{ Exception -> 0x02c0 }
            java.net.URL r13 = new java.net.URL     // Catch:{ Exception -> 0x02c0 }
            r13.<init>(r1)     // Catch:{ Exception -> 0x02c0 }
            java.net.URLConnection r14 = r13.openConnection()     // Catch:{ Exception -> 0x02c0 }
            java.net.HttpURLConnection r14 = (java.net.HttpURLConnection) r14     // Catch:{ Exception -> 0x02c0 }
            if (r14 == 0) goto L_0x028d
            java.lang.String r15 = "Cookie"
            java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02c0 }
            r6.<init>()     // Catch:{ Exception -> 0x02c0 }
            java.lang.String r0 = "AppInventor = "
            java.lang.StringBuilder r0 = r6.append(r0)     // Catch:{ Exception -> 0x02c0 }
            java.lang.StringBuilder r0 = r0.append(r2)     // Catch:{ Exception -> 0x02c0 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x02c0 }
            r14.addRequestProperty(r15, r0)     // Catch:{ Exception -> 0x02c0 }
            com.google.appinventor.components.runtime.util.HashDatabase r0 = db     // Catch:{ Exception -> 0x02c0 }
            com.google.appinventor.components.runtime.util.HashFile r0 = r0.getHashFile(r3)     // Catch:{ Exception -> 0x02c0 }
            r6 = r0
            if (r6 == 0) goto L_0x00b9
            java.lang.String r0 = "If-None-Match"
            java.lang.String r15 = r6.getHash()     // Catch:{ Exception -> 0x0066 }
            r14.addRequestProperty(r0, r15)     // Catch:{ Exception -> 0x0066 }
        L_0x00b9:
            java.lang.String r0 = "GET"
            r14.setRequestMethod(r0)     // Catch:{ Exception -> 0x02c0 }
            int r0 = r14.getResponseCode()     // Catch:{ Exception -> 0x02c0 }
            r7 = r0
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0287 }
            r0.<init>()     // Catch:{ Exception -> 0x0287 }
            java.lang.String r15 = "asset = "
            java.lang.StringBuilder r0 = r0.append(r15)     // Catch:{ Exception -> 0x0287 }
            java.lang.StringBuilder r0 = r0.append(r3)     // Catch:{ Exception -> 0x0287 }
            java.lang.String r15 = " responseCode = "
            java.lang.StringBuilder r0 = r0.append(r15)     // Catch:{ Exception -> 0x0287 }
            java.lang.StringBuilder r0 = r0.append(r7)     // Catch:{ Exception -> 0x0287 }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x0287 }
            android.util.Log.d(r9, r0)     // Catch:{ Exception -> 0x0287 }
            java.io.File r0 = r8.getParentFile()     // Catch:{ Exception -> 0x0287 }
            r9 = r0
            java.lang.String r0 = "ETag"
            java.lang.String r0 = r14.getHeaderField(r0)     // Catch:{ Exception -> 0x0287 }
            r10 = r0
            r0 = 304(0x130, float:4.26E-43)
            if (r7 != r0) goto L_0x00f4
            return r8
        L_0x00f4:
            boolean r0 = r9.exists()     // Catch:{ Exception -> 0x0287 }
            if (r0 != 0) goto L_0x011e
            boolean r0 = r9.mkdirs()     // Catch:{ Exception -> 0x02c0 }
            if (r0 == 0) goto L_0x0103
            r17 = r5
            goto L_0x0120
        L_0x0103:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x02c0 }
            java.lang.StringBuilder r15 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x02c0 }
            r15.<init>()     // Catch:{ Exception -> 0x02c0 }
            r17 = r5
            java.lang.String r5 = "Unable to create assets directory "
            java.lang.StringBuilder r5 = r15.append(r5)     // Catch:{ Exception -> 0x0299 }
            java.lang.StringBuilder r5 = r5.append(r9)     // Catch:{ Exception -> 0x0299 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0299 }
            r0.<init>(r5)     // Catch:{ Exception -> 0x0299 }
            throw r0     // Catch:{ Exception -> 0x0299 }
        L_0x011e:
            r17 = r5
        L_0x0120:
            boolean r0 = r8.exists()     // Catch:{ Exception -> 0x0283 }
            if (r0 == 0) goto L_0x014f
            if (r12 == 0) goto L_0x014f
            r0 = 1
            boolean r0 = r8.setWritable(r0, r0)     // Catch:{ Exception -> 0x0299 }
            if (r0 == 0) goto L_0x0130
            goto L_0x014f
        L_0x0130:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ Exception -> 0x0299 }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0299 }
            r5.<init>()     // Catch:{ Exception -> 0x0299 }
            java.lang.String r15 = "Unable to make "
            java.lang.StringBuilder r5 = r5.append(r15)     // Catch:{ Exception -> 0x0299 }
            java.lang.StringBuilder r5 = r5.append(r8)     // Catch:{ Exception -> 0x0299 }
            java.lang.String r15 = " writable"
            java.lang.StringBuilder r5 = r5.append(r15)     // Catch:{ Exception -> 0x0299 }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x0299 }
            r0.<init>(r5)     // Catch:{ Exception -> 0x0299 }
            throw r0     // Catch:{ Exception -> 0x0299 }
        L_0x014f:
            java.io.BufferedInputStream r0 = new java.io.BufferedInputStream     // Catch:{ Exception -> 0x0283 }
            java.io.InputStream r5 = r14.getInputStream()     // Catch:{ Exception -> 0x0283 }
            r15 = 4096(0x1000, float:5.74E-42)
            r0.<init>(r5, r15)     // Catch:{ Exception -> 0x0283 }
            r5 = r0
            java.io.BufferedOutputStream r0 = new java.io.BufferedOutputStream     // Catch:{ Exception -> 0x0283 }
            java.io.FileOutputStream r15 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x0283 }
            r15.<init>(r8)     // Catch:{ Exception -> 0x0283 }
            r18 = r6
            r6 = 4096(0x1000, float:5.74E-42)
            r0.<init>(r15, r6)     // Catch:{ Exception -> 0x0283 }
            r6 = r0
        L_0x016a:
            int r0 = r5.read()     // Catch:{ IOException -> 0x01da, all -> 0x01d4 }
            r15 = -1
            if (r0 != r15) goto L_0x01c6
            r6.flush()     // Catch:{ IOException -> 0x01da, all -> 0x01d4 }
            r6.close()     // Catch:{ Exception -> 0x0283 }
            if (r12 == 0) goto L_0x01c1
            java.lang.String r0 = LOG_TAG     // Catch:{ Exception -> 0x0283 }
            java.lang.String r15 = r8.getAbsolutePath()     // Catch:{ Exception -> 0x0283 }
            r16 = r5
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x0283 }
            r5.<init>()     // Catch:{ Exception -> 0x0283 }
            r19 = r7
            java.lang.String r7 = "Making file read-only: "
            java.lang.StringBuilder r5 = r5.append(r7)     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = r5.append(r15)     // Catch:{ Exception -> 0x027f }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x027f }
            android.util.Log.i(r0, r5)     // Catch:{ Exception -> 0x027f }
            boolean r0 = r8.setReadOnly()     // Catch:{ Exception -> 0x027f }
            if (r0 == 0) goto L_0x01a2
        L_0x01a0:
            goto L_0x022c
        L_0x01a2:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x027f }
            r5.<init>()     // Catch:{ Exception -> 0x027f }
            java.lang.String r7 = "Unable to make "
            java.lang.StringBuilder r5 = r5.append(r7)     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = r5.append(r8)     // Catch:{ Exception -> 0x027f }
            java.lang.String r7 = " read-only."
            java.lang.StringBuilder r5 = r5.append(r7)     // Catch:{ Exception -> 0x027f }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x027f }
            r0.<init>(r5)     // Catch:{ Exception -> 0x027f }
        L_0x01c0:
            throw r0     // Catch:{ Exception -> 0x027f }
        L_0x01c1:
            r16 = r5
            r19 = r7
            goto L_0x022c
        L_0x01c6:
            r16 = r5
            r19 = r7
            r6.write(r0)     // Catch:{ IOException -> 0x01d2 }
            r5 = r16
            r7 = r19
            goto L_0x016a
        L_0x01d2:
            r0 = move-exception
            goto L_0x01df
        L_0x01d4:
            r0 = move-exception
            r16 = r5
            r19 = r7
            goto L_0x0233
        L_0x01da:
            r0 = move-exception
            r16 = r5
            r19 = r7
        L_0x01df:
            java.lang.String r5 = LOG_TAG     // Catch:{ all -> 0x0232 }
            java.lang.String r7 = "copying assets"
            android.util.Log.e(r5, r7, r0)     // Catch:{ all -> 0x0232 }
            r11 = 1
            r6.close()     // Catch:{ Exception -> 0x027f }
            if (r12 == 0) goto L_0x022c
            java.lang.String r0 = r8.getAbsolutePath()     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r7 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x027f }
            r7.<init>()     // Catch:{ Exception -> 0x027f }
            java.lang.String r15 = "Making file read-only: "
            java.lang.StringBuilder r7 = r7.append(r15)     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r0 = r7.append(r0)     // Catch:{ Exception -> 0x027f }
            java.lang.String r0 = r0.toString()     // Catch:{ Exception -> 0x027f }
            android.util.Log.i(r5, r0)     // Catch:{ Exception -> 0x027f }
            boolean r0 = r8.setReadOnly()     // Catch:{ Exception -> 0x027f }
            if (r0 == 0) goto L_0x020d
            goto L_0x01a0
        L_0x020d:
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x027f }
            r5.<init>()     // Catch:{ Exception -> 0x027f }
            java.lang.String r7 = "Unable to make "
            java.lang.StringBuilder r5 = r5.append(r7)     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = r5.append(r8)     // Catch:{ Exception -> 0x027f }
            java.lang.String r7 = " read-only."
            java.lang.StringBuilder r5 = r5.append(r7)     // Catch:{ Exception -> 0x027f }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x027f }
            r0.<init>(r5)     // Catch:{ Exception -> 0x027f }
            goto L_0x01c0
        L_0x022c:
            r14.disconnect()     // Catch:{ Exception -> 0x027f }
            r7 = r19
            goto L_0x0290
        L_0x0232:
            r0 = move-exception
        L_0x0233:
            r6.close()     // Catch:{ Exception -> 0x027f }
            if (r12 == 0) goto L_0x027b
            java.lang.String r5 = LOG_TAG     // Catch:{ Exception -> 0x027f }
            java.lang.String r7 = r8.getAbsolutePath()     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r15 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x027f }
            r15.<init>()     // Catch:{ Exception -> 0x027f }
            r20 = r6
            java.lang.String r6 = "Making file read-only: "
            java.lang.StringBuilder r6 = r15.append(r6)     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r6 = r6.append(r7)     // Catch:{ Exception -> 0x027f }
            java.lang.String r6 = r6.toString()     // Catch:{ Exception -> 0x027f }
            android.util.Log.i(r5, r6)     // Catch:{ Exception -> 0x027f }
            boolean r5 = r8.setReadOnly()     // Catch:{ Exception -> 0x027f }
            if (r5 != 0) goto L_0x027d
            java.io.IOException r0 = new java.io.IOException     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x027f }
            r5.<init>()     // Catch:{ Exception -> 0x027f }
            java.lang.String r6 = "Unable to make "
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch:{ Exception -> 0x027f }
            java.lang.StringBuilder r5 = r5.append(r8)     // Catch:{ Exception -> 0x027f }
            java.lang.String r6 = " read-only."
            java.lang.StringBuilder r5 = r5.append(r6)     // Catch:{ Exception -> 0x027f }
            java.lang.String r5 = r5.toString()     // Catch:{ Exception -> 0x027f }
            r0.<init>(r5)     // Catch:{ Exception -> 0x027f }
            throw r0     // Catch:{ Exception -> 0x027f }
        L_0x027b:
            r20 = r6
        L_0x027d:
            throw r0     // Catch:{ Exception -> 0x027f }
        L_0x027f:
            r0 = move-exception
            r7 = r19
            goto L_0x02c3
        L_0x0283:
            r0 = move-exception
            r19 = r7
            goto L_0x02c3
        L_0x0287:
            r0 = move-exception
            r17 = r5
            r19 = r7
            goto L_0x02c3
        L_0x028d:
            r17 = r5
            r11 = 1
        L_0x0290:
            if (r11 == 0) goto L_0x029b
            int r0 = r4 + 1
            java.io.File r0 = getFile(r1, r2, r3, r0)     // Catch:{ Exception -> 0x0299 }
            return r0
        L_0x0299:
            r0 = move-exception
            goto L_0x02c3
        L_0x029b:
            r0 = 200(0xc8, float:2.8E-43)
            if (r7 != r0) goto L_0x02be
            java.util.Date r0 = new java.util.Date
            r0.<init>()
            com.google.appinventor.components.runtime.util.HashFile r5 = new com.google.appinventor.components.runtime.util.HashFile
            r5.<init>((java.lang.String) r3, (java.lang.String) r10, (java.util.Date) r0)
            com.google.appinventor.components.runtime.util.HashDatabase r6 = db
            com.google.appinventor.components.runtime.util.HashFile r6 = r6.getHashFile(r3)
            if (r6 != 0) goto L_0x02b8
            com.google.appinventor.components.runtime.util.HashDatabase r6 = db
            r6.insertHashFile(r5)
            goto L_0x02bd
        L_0x02b8:
            com.google.appinventor.components.runtime.util.HashDatabase r6 = db
            r6.updateHashFile(r5)
        L_0x02bd:
            return r8
        L_0x02be:
            r5 = 0
            return r5
        L_0x02c0:
            r0 = move-exception
            r17 = r5
        L_0x02c3:
            java.lang.String r5 = LOG_TAG
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r9 = "Exception while fetching "
            java.lang.StringBuilder r6 = r6.append(r9)
            java.lang.StringBuilder r6 = r6.append(r1)
            java.lang.String r6 = r6.toString()
            android.util.Log.e(r5, r6, r0)
            int r5 = r4 + 1
            java.io.File r5 = getFile(r1, r2, r3, r5)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.appinventor.components.runtime.util.AssetFetcher.getFile(java.lang.String, java.lang.String, java.lang.String, int):java.io.File");
    }

    private static String byteArray2Hex(byte[] hash) {
        Formatter formatter = new Formatter();
        int length = hash.length;
        for (int i = 0; i < length; i++) {
            formatter.format("%02x", new Object[]{Byte.valueOf(hash[i])});
        }
        return formatter.toString();
    }
}
