package com.google.appinventor.components.runtime.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.nfc.tech.NdefFormatable;
import android.os.Parcelable;
import android.util.Log;
import com.google.appinventor.components.runtime.NearField;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookieStore;
import java.nio.charset.Charset;
import java.util.Locale;
import org.shaded.apache.http.protocol.HTTP;

public class GingerbreadUtil {
    private static final String LOG_TAG = GingerbreadUtil.class.getSimpleName();

    private GingerbreadUtil() {
    }

    public static CookieHandler newCookieManager() {
        return new CookieManager();
    }

    public static boolean clearCookies(CookieHandler cookieHandler) {
        CookieStore cookieStore;
        if (!(cookieHandler instanceof CookieManager) || (cookieStore = ((CookieManager) cookieHandler).getCookieStore()) == null) {
            return false;
        }
        cookieStore.removeAll();
        return true;
    }

    public static NfcAdapter newNfcAdapter(Context context) {
        return NfcAdapter.getDefaultAdapter(context);
    }

    public static void enableNFCWriteMode(Activity activity, NfcAdapter nfcAdapter, String textToWrite) {
        NdefMessage msg = new NdefMessage(new NdefRecord[]{createTextRecord(textToWrite, true)});
        try {
            nfcAdapter.getClass().getMethod("enableForegroundNdefPush", new Class[]{Activity.class, NdefMessage.class}).invoke(nfcAdapter, new Object[]{activity, msg});
        } catch (NoSuchMethodException e) {
            throw new UnsupportedOperationException("This device does not support NFC");
        } catch (InvocationTargetException e2) {
            Log.e(LOG_TAG, "Unable to write NDEF tag", e2);
        } catch (IllegalAccessException e3) {
            Log.e(LOG_TAG, "Unable to write NDEF tag", e3);
        }
    }

    public static void disableNFCAdapter(Activity activity, NfcAdapter nfcAdapter) {
        try {
            nfcAdapter.getClass().getMethod("disableForegroundNdefPush", new Class[]{Activity.class}).invoke(nfcAdapter, new Object[]{activity});
        } catch (NoSuchMethodException e) {
            throw new UnsupportedOperationException("This device does not support NFC");
        } catch (InvocationTargetException e2) {
            Log.e(LOG_TAG, "Unable to write NDEF tag", e2);
        } catch (IllegalAccessException e3) {
            Log.e(LOG_TAG, "Unable to write NDEF tag", e3);
        }
    }

    public static NdefRecord createTextRecord(String payload, boolean encodeInUtf8) {
        byte[] langBytes = Locale.getDefault().getLanguage().getBytes(Charset.forName("US-ASCII"));
        byte[] textBytes = payload.getBytes(Charset.forName(encodeInUtf8 ? "UTF-8" : HTTP.UTF_16));
        int utfBit = encodeInUtf8 ? 0 : 128;
        byte[] data = new byte[(langBytes.length + 1 + textBytes.length)];
        data[0] = (byte) ((char) (langBytes.length + utfBit));
        System.arraycopy(langBytes, 0, data, 1, langBytes.length);
        System.arraycopy(textBytes, 0, data, langBytes.length + 1, textBytes.length);
        return new NdefRecord(1, NdefRecord.RTD_TEXT, new byte[0], data);
    }

    public static void resolveNFCIntent(Intent intent, NearField nfc) {
        NdefMessage[] msgs;
        if (!"android.nfc.action.NDEF_DISCOVERED".equals(intent.getAction())) {
            Log.e("nearfield", "Unknown intent " + intent);
        } else if (nfc.ReadMode()) {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra("android.nfc.extra.NDEF_MESSAGES");
            if (rawMsgs != null) {
                msgs = new NdefMessage[rawMsgs.length];
                for (int i = 0; i < rawMsgs.length; i++) {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }
            } else {
                byte[] empty = new byte[0];
                msgs = new NdefMessage[]{new NdefMessage(new NdefRecord[]{new NdefRecord(5, empty, empty, empty)})};
            }
            nfc.TagRead(new String(msgs[0].getRecords()[0].getPayload()).substring(3));
        } else {
            Tag detectedTag = (Tag) intent.getParcelableExtra("android.nfc.extra.TAG");
            NdefMessage msg = null;
            if (nfc.WriteType() == 1) {
                msg = new NdefMessage(new NdefRecord[]{createTextRecord(nfc.TextToWrite(), true)});
            }
            if (writeNFCTag(msg, detectedTag)) {
                nfc.TagWritten();
            }
        }
    }

    public static boolean writeNFCTag(NdefMessage message, Tag tag) {
        int size = message.toByteArray().length;
        try {
            Ndef ndef = Ndef.get(tag);
            if (ndef != null) {
                ndef.connect();
                if (!ndef.isWritable() || ndef.getMaxSize() < size) {
                    return false;
                }
                ndef.writeNdefMessage(message);
                return true;
            }
            NdefFormatable format = NdefFormatable.get(tag);
            if (format == null) {
                return false;
            }
            try {
                format.connect();
                format.format(message);
                return true;
            } catch (IOException e) {
                return false;
            }
        } catch (Exception e2) {
            return false;
        }
    }
}
